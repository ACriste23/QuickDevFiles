package project4;
import java.util.*;

//If the first index is 3, the only option is to go 3 spaces right. 
//Afterwards you have a maximum of 2 options, either go left or right 'n' spaces.
//If it reaches the last index, accumulate it into # of solutions. 
//No correlation between # of steps taken and size of array. 
//If it repeats a step or ends up at a previous location, then no solution. 
//Create a tree from the indices, right and left, use it recursively to find 0. 


public class WayFinderAlt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner arrayInput = new Scanner(System.in);
		
		String str = "SAWNRELKIM";
		
		String firstName,lastName;
		
		String s1 ="",s2="",s3="",s4="";
		
		int num1,num2,num3;
		
		String reverse = "";
		
		System.out

	}

}
