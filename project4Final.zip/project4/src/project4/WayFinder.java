package project4;
import java.util.*;

/*This class produces all possible solutions to a number puzzle(array of integers).
 * @author Antonio Criste(abc590@nyu.edu)
 *@version 04/11/2021
 * */

public class WayFinder {
	
	
	
	//ArrayList that contains list of each list of indices visited for a solution.
	static ArrayList<ArrayList<Integer>> finalPaths = new ArrayList<ArrayList<Integer>>();
	
	
	
	
	//Searches for a list of valid possible solutions to number puzzle
	//@Param starting index for array, array to be searched, ArrayList of Directions taken to solve puzzle, ArrayList of indices visited to solve puzzle.
	static void pathFinder(int index, int[] squares,ArrayList<String> direction,ArrayList<Integer> indices) 
	{
		//We start at Index 0
		//The only initial path is right.
		//Afterwards, decide if you can go right or left.
		//Store an initial path, make sure that path is recorded.
		if(index==squares.length-1) 
		{
			
			printPaths(squares,direction);
			System.out.println();
			finalPaths.add(indices);
			return;
		}
		if(indices.contains(index))
		{
			return;
		}
				

		else 
		{
			if(index+squares[index] < squares.length) 
			{
				@SuppressWarnings("unchecked")
				ArrayList<Integer> indices2 = (ArrayList<Integer>) indices.clone();
				@SuppressWarnings("unchecked")
				ArrayList<String> direction2 = (ArrayList<String>) direction.clone();
				//If you don't do copies of the OG list or the root, and modify it to go left/right.
				//The root will edit itself and the root will change and you won't be able to traverse.
				indices2.add(index);
				direction2.add("R");
				
				
				pathFinder(index+squares[index],squares,direction2,indices2);
			}
			if(index -squares[index] >0) 
			{
				@SuppressWarnings("unchecked")
				ArrayList<Integer> indices3 = (ArrayList<Integer>) indices.clone();
				@SuppressWarnings("unchecked")
				ArrayList<String> direction3 = (ArrayList<String>) direction.clone();
				
				
				//If you don't do copies of the OG list, the list will forget path and you won't traverse.
				indices3.add(index);
				direction3.add("L");
				
				pathFinder(index-squares[index],squares,direction3,indices3);
			}
		}
	}
	
	
	
	
	/*@param, Number array to be solved, Direction taken in path, and starting index
	 * Functions as a helper method for printPaths.
	 * */
	static void print(int[] squares, String direction, int index) 
	{
		System.out.print("[");
		for(int i = 0;i<squares.length;i++) 
		{
			
			if(i == squares.length-1) 
			{
				System.out.printf(" %d ", squares[i]);
			}
			
			else if(i == index) 
			{
				
			System.out.printf(" %d%s, ",squares[i],direction);
				
			}
			else 
			{
				System.out.printf(" %d%s, ", squares[i]," ");
			}
			
		}
		System.out.println("]");
	}
	
	
	
	
	/*Prints out series of paths taken to solve puzzle. 
	 * @param, Number array to be solved, List of Directions taken by pathFinder method.
	 * */
	static void printPaths(int[]squares,ArrayList<String>direction) 
	{
		int i = 0;
		while(i!=squares.length-1) 
		{
			boolean right = direction.remove(0).equalsIgnoreCase("R");
			if(right == true) 
			{
				print(squares,"R",i);
				i += squares[i];
			
			}
			else 
			{
				print(squares,"L",i);
				i-=squares[i];
			}
		}
	}
	
	
	
	/*Main function to check if command prompt argument is valid.
	 *Then uses pathFinder Function to find all possible solutions if valid.
	 *@param command line argument
	 *produces string representation of all possible solutions to puzzle. 
	 * */
	public static void main(String[] args) 
	{
		
		//First 2 functions check if length of list is valid.
		if(args.length==0) 
		{
			System.out.println("List has no values");
			System.exit(1);
		}
		
		if(args.length<2) 
		{
			System.err.println("Error: You must enter 2 or more values.");
			System.exit(1);
		}
		
		//array of all valuables entered in command prompt. 
		int[] squares = new int[args.length];

		
		//Checks if all entries in command prompt are string.
		//If so, adds each entry into 'squares' array.
		//@throws NumberFormatException if any entry in command prompt is not an Integer type.
		for(int i = 0;i<args.length;i++) 
		{
			
			try 
			{
				if(Integer.parseInt(args[i])<0 ) 
				{
					System.err.printf("ERROR: %d value (Negative Number)",Integer.parseInt(args[i]));
					System.exit(1);
				}
				
				if( Integer.parseInt(args[i])>99) 
				{
					System.err.printf("ERROR: %d value (Larger than 99)",Integer.parseInt(args[i]));
					System.exit(1);
				}
				
				if(i == args.length-1 &&  Integer.parseInt(args[args.length-1])!=0) 
				{
					System.err.println("ERROR: Invalid End, Must be 0");
					System.exit(1);
				}
				else 
					{
					squares[i] = Integer.parseInt(args[i]);
					}
			}
			catch(NumberFormatException e) 
			{
				System.err.println("ERROR: Invalid input, must be an Integer type");
				System.exit(1);
			}
			
		}
		
		
		//List of Indices and Directions to add paths.
		//for pathFinder function.
		ArrayList<String> Solutions = new ArrayList<String>();
		ArrayList<Integer> indices = new ArrayList<Integer>();
		pathFinder(0, squares,Solutions,indices);
		if(finalPaths.size() == 0) 
		{
			System.out.println("No way through this puzzle");
		}
		else 
		{
			System.out.println("There are "+finalPaths.size()+" ways through this puzzle");

		}
	}
	
	
}
