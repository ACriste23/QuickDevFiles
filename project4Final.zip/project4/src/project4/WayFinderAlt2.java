package project4;

public class WayFinderAlt2 {
	
	
	
	public int Solutions(int[]array, int[] numberArray, int i) 
	{
		if(array[i]==0) 
		{
			return 1;
		}
		
		else if(numberArray) 
		{
			return 0;
		}
		
		else if(array[i]!=0) 
		{
			return Solutions(array,numberArray + array[i], int i - array[i]) 
					+ Solutions(array,numberArray+array[i], int i + array[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
