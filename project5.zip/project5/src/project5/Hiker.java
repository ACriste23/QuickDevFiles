package project5;
import java.util.*;
//In the BSTMountainAdventure class, make sure you create "Deep" copies of the Hiker object. 
//	


//Hiker object stores amount of food,axes and rafts to traversal.
public class Hiker {
	int foodNum;
	int axeNum;
	int raftNum;
	
	
	
	//Getter and Setter methods.
	public int getFoodNum() {
		return foodNum;
	}
	public void setFoodNum(int foodNum) {
		this.foodNum = foodNum;
	}
	public int getAxeNum() {
		return axeNum;
	}
	public void setAxeNum(int axeNum) {
		this.axeNum = axeNum;
	}
	public int getRaftNum() {
		return raftNum;
	}
	public void setRaftNum(int raftNum) {
		this.raftNum = raftNum;
	}
	
	//Constructor 1 for brand new Hiker object.
	public Hiker() 
	{
		this.foodNum=0;
		this.axeNum=0;
		this.raftNum=0;
	}
	
	//Constructor 2 for Hiker object cloned from older Hiker object.
	public Hiker(Hiker oldHiker) 
	{
		this.setFoodNum(oldHiker.getFoodNum());
		this.axeNum = oldHiker.axeNum;
		this.raftNum = oldHiker.raftNum;
	}
	
	
	
	
	

}
