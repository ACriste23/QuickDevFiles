package project5;

import java.util.*;



//@Author Joanna Klukowska
//Instead of using generics, uses RestStop as data.
@SuppressWarnings("hiding")
public class BSTMountain<RestStop extends Comparable<RestStop>> {

	class BSTNode
	{
		RestStop data;
		BSTNode left;
		BSTNode right;
		
		BSTNode() 
		{
			left = right = null;
		}
		
		BSTNode(RestStop data )
		{
			this.data = data;
		}
		
		BSTNode(RestStop data, BSTNode l, BSTNode r)
		{
			left = l; right = r;
			this.data = data;
		}
		
	}
	
	
	protected BSTNode root;
	protected Comparator<RestStop> comparator;
	
	private boolean found; 
	private boolean added;
	
	public BSTMountain() 
	{
		root = null;
		comparator = null;
	}
	
	public void BST(Comparator<RestStop> comparator) 
	{
		this.comparator=comparator;
	}
	
	public void setRight(BSTNode p) 
	{
		root.right=p;
	}
	
	
	
	
	public boolean add(RestStop data) 
	{
		added = false;
		if(data==null)
			return added;
		
		root = addhelp(data,root);
		return added;
	}
	
	private BSTNode addhelp(RestStop data, BSTNode node) 
	{
		if(node == null) 
		{
			added = true;
			return new BSTNode(data);
		}
		
		int comp =0;
		if(comparator == null) 
		{
			comp = node.data.compareTo(data);
		}
		else 
		{
			comp = comparator.compare(node.data, data);
		}
		
		if (comp>0) 
		{
			node.left = addhelp(data,node.left);
		}
		else if(comp<0) 
		{
			node.right = addhelp(data,node.right);
		}
		else 
		{
			added = false;
			return node;
		}
		return node;
	}
	
	
	
	
	public int size() 
	{
		return sizeHelp(root);
	}
	
	private int sizeHelp(BSTNode root) 
	{
		if(root==null) 
		{
			return 0;
		}
		
		return 1 + sizeHelp(root.left) + sizeHelp(root.right);
	}
	
	public int countLeaves() 
	{
		return leafCount(root);
	}
	
	private int leafCount(BSTNode root) 
	{
		if(root ==null) 
		{
			return 0;
		}
		if(root.left==null && root.right==null)
			return 1;
		else 
		{
			return leafCount(root.left)+leafCount(root.right);
		}
	}
	
	
	
	
	  public int countInternal(){
	        return countInternal(root);
	    }
	    public int countInternal(BSTNode root){
	        if (root == null){
	            return 0;
	        }
	        if (root.left == null && root.right == null)
	            return 0;
	        else
	        {
	            return 1 + countInternal(root.left) + countInternal(root.right);
	        }
	        
	    }    

	    public void inorder (){
	       inorderHelp(root,""); 
	    }  

	    public void inorderHelp (BSTNode root, String string){
	        inorderHelp(root.left, string);
	        string +=root.data+" ";
	        inorderHelp(root.right, string);
	    } 
	    /**
		 * Removes the specified element from this tree if it is present. 
		 * Returns true if this tree contained the element (or equivalently, 
	     * if this tree changed as a result of the call). 
	     * (This tree will not contain the element once the call returns.)
		 * @param target object to be removed from this tree, if present
	     * @return true if this set contained the specified element 
	     * @throws NullPointerException if the specified element is null  
		 */
		public boolean remove(RestStop target)
		{
	        //replace root with a reference to the tree after target was removed 
			root = recRemove(target, root);

			return found;
		}


		/*
		 * Actual recursive implementation of remove method: find the node to remove.
	     *
		 * This function recursively finds and eventually removes the node with the target element 
	     * and returns the reference to the modified tree to the caller. 
	     * 
		 * @param target object to be removed from this tree, if present
	     * @param node node at which the recursive call is made 
		 */
		private BSTNode recRemove(RestStop target, BSTNode node)
		{
			if (node == null)  { //value not found 
				found = false;
	            return node; 
	        }
	        
	        //decide how comparisons should be done 
	        int comp = 0 ;
	        if (comparator == null ) //use natural ordering of the elements 
	            comp = target.compareTo(node.data); 
	        else                     //use the comparator 
	            comp = comparator.compare(target, node.data ) ;

	        
			if (comp < 0)       // target might be in a left subtree 
				node.left = recRemove(target, node.left);
			else if (comp > 0)  // target might be in a right subtree 
				node.right = recRemove(target, node.right );
			else {          // target found, now remove it 
				node = removeNode(node);
				found = true;
			}
			return node;
		}

		/*
		 * Actual recursive implementation of remove method: perform the removal.
		 *
		 * @param target the item to be removed from this tree
		 * @return a reference to the node itself, or to the modified subtree
		 */
		private BSTNode removeNode(BSTNode node)
		{
			RestStop newData;
			if (node.left == null)   //handle the leaf and one child node with right subtree 
				return node.right ; 
			else if (node.right  == null)  //handle one child node with left subtree 
				return node.left;
			else {                   //handle nodes with two children 
				newData = getPredecessor(node.left);
				node.data = newData;
				node.left = recRemove(newData, node.left);
				return node;
			}
		}

		/*
		 * Returns the information held in the rightmost node of subtree
		 *
		 * @param subtree root of the subtree within which to search for the rightmost node
		 * @return returns data stored in the rightmost node of subtree
		 */
		private RestStop getPredecessor(BSTNode subtree)
		{
			if (subtree==null) //this should not happen 
	            throw new NullPointerException("getPredecessor called with an empty subtree");
			BSTNode temp = subtree;
			while (temp.right  != null)
				temp = temp.right ;
			return temp.data;
		}





	    public String toStringTree( ) {
	        StringBuffer sb = new StringBuffer(); 
	        toStringTree(sb, root, 0);
	        return sb.toString();
	    }

	    //uses preorder traversal to display the tree 
	    //WARNING: will not work if the data.toString returns more than one line 
	    private void toStringTree( StringBuffer sb, BSTNode node, int level ) {
	        //display the node 
	        if (level > 0 ) {
	            for (int i = 0; i < level-1; i++) {
	                sb.append("   ");
	            }
	            sb.append("|--");
	        }
	        if (node == null) {
	            sb.append( "->\n"); 
	            return;
	        }
	        else {
	            sb.append( (RestStop)node.data.toString() + "\n"); 
	        }

	        //display the left subtree 
	        toStringTree(sb, node.left, level+1); 
	        //display the right subtree 
	        toStringTree(sb, node.right, level+1); 
	    }
	    
	    
	    
	 
	    //Searches for all possible Root -> Leaf Paths in a BST.
	    //@param BSTNode to traverse BST
	    //@return ArrayList<ArrayList<RestStop>> of all possible paths.
	    public ArrayList<ArrayList<RestStop>> paths(BSTNode node)
	    {
	    	ArrayList<ArrayList<RestStop>> allPossiblePaths = 
	    			new ArrayList<ArrayList<RestStop>>();
	    	ArrayList<RestStop> onePath = new ArrayList<RestStop>();
	    	return pathsRecur(node,allPossiblePaths,0,onePath);
	    }
	    
	    @SuppressWarnings("unchecked")
		private ArrayList<ArrayList<RestStop>> pathsRecur(BSTNode node, 
	    		ArrayList<ArrayList<RestStop>> paths,int pathLen,ArrayList<RestStop> onePath)
	    {
	    	if(node == null) 
	    	{
	    		return paths;
	    	}
	    	
	    	onePath.add((RestStop) node.data);
	    	
	    	if(node.left == null && node.right == null) 
	    	{
	    		paths.add(onePath);
	    		return paths;
	    		
	    	}
	    	
	    	else 
	    	{
	    		pathsRecur(node.left,paths,pathLen,new ArrayList<>(onePath));
	    		pathsRecur(node.right,paths,pathLen,new ArrayList<>(onePath));
	    	}
	    	return paths;
	   
	    }
	    
	    
	    //Filters out paths for ones as long as path to deepest node.
	    //@param ArrayList<ArrayList<RestStop>> to check paths.
	    //@return ArrayList of ArrayList<RestStops> of same-sized paths.
	    public ArrayList<ArrayList<RestStop>> longPaths(ArrayList<ArrayList<RestStop>> pathList)
	    {
	    	ArrayList<ArrayList<RestStop>> longPaths = new ArrayList<ArrayList<RestStop>>();
	    	int i = 0;
	    	while(i<pathList.size())
	    	{
	    		ArrayList<RestStop> path = pathList.get(i);
	    		if(path.size() == this.getHeight(this.root)) 
	    		{
	    			longPaths.add(path);
	    		}
	    		i++;
	    	}
	    	return longPaths;
	    }
	    
	    
	    //Recovers height of a node.
	    //@param BSTNode to find height of.
	    //@return int height of node.
	    public int getHeight(BSTNode root) 
	    {
	    	if(root == null) 
	    	{
	    		return 0;
	    	}
	    	
	    	return whichBigger(getHeight(root.left),getHeight(root.right))+1;
	    }
	    
	    //Determines which number is bigger
	    //@param numbers a and b to be compared
	    //@returns bigger number
	    public int whichBigger(int a, int b) 
	    {
	    	if(a>=b) 
	    	{
	    		return a;
	    	}
	    	else 
	    	{
	    		return b;
	    	}
	    }
	    
	    
	    
	    //Determines the depth of a node
	    //@param Node to have depth checked.
	    //@return depth of Node.
	    public int mountainDepth(BSTNode root) 
	    {
	    	if(root ==null) 
	    	{
	    		return 0;
	    	}
	    	if(root.left==null && root.right==null) 
	    	{
	    		return 1;
	    	}
	    	else 
	    	{
	    		int L = mountainDepth(root.left);
	    		int R = mountainDepth(root.right);
	    		
	    		return (1+((L<R)?L :R));
	    	}
	    }
	    
	
	    
	    
}

