package project5;

public class RestStop implements Comparable<RestStop>{

	//Compares RestStop object to other RestStop object
	//based on label
	//@param RestStop object to be compared to
	//@returns numerical value indicating difference.
	@Override
	public int compareTo(RestStop o) 
	{
		return this.label.compareTo(o.label);
	}
	
	//RestSTop contains a label, and amount of supplies and obstacles stored as int variables.
	
	String label;
	int foodCount;
	int cliffCount;
	int axeCount;
	int raftCount;
	

	int treeCount;
	int riverCount;
	
	
	//Getters and Setters for access.
	public String toString()
	{
		return this.label;
	}	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public int getAxeCount() {
		return axeCount;
	}
	public void setAxeCount(int axeCount) {
		this.axeCount = axeCount;
	}
	public int getRaftCount() {
		return raftCount;
	}
	public void setRaftCount(int raftCount) {
		this.raftCount = raftCount;
	}
	public int getFoodCount() {
		return foodCount;
	}
	public void setFoodCount(int foodCount) {
		this.foodCount = foodCount;
	}
	public int getCliffCount() {
		return cliffCount;
	}
	public void setCliffCount(int cliffCount) {
		this.cliffCount = cliffCount;
	}
	public int getTreeCount() {
		return treeCount;
	}
	public void setTreeCount(int treeCount) {
		this.treeCount = treeCount;
	}
	public int getRiverCount() {
		return riverCount;
	}
	public void setRiverCount(int riverCount) {
		this.riverCount = riverCount;
	}
	
	

}
