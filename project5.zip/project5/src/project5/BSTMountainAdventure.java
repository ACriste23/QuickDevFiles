package project5;

import java.io.*;
import java.util.*;
import project5.BSTMountain.BSTNode;

public class BSTMountainAdventure {
	/*Name: Antonio Criste(abc590@nyu.edu)
	 *
	 * 
	 */
	
	//List of solutions to BSTMountain entered as a Text file. 
	static ArrayList<ArrayList<RestStop>> finalPaths2 = new ArrayList<ArrayList<RestStop>>();
	
	
	//@param BSTMountain, BSTNode, Arraylist of RestStops whichc consists of a path,
	//A Hiker object to traverse the list. 
	//Creates a valid path, which is added to the ArrayList of RestStops above, called finalPaths2 
	@SuppressWarnings({ "rawtypes", "unchecked" })
	static void pathFinder(BSTMountain mountain,BSTNode root,ArrayList<RestStop> paths,Hiker oldHiker) 
	{	
		
		paths.add((RestStop) root.data);
		if(root.left == null && root.right == null) 
		{
			 
			if( paths.size()==mountain.getHeight(mountain.root)) 
			{				
				finalPaths2.add(paths);
				return;
			}
			else 
			{
				return;
			}
		}
		
		

		
		
		
		
		//Updates the hiker based on the node that he is currently at.
		oldHiker= hikerUpdate(oldHiker,(RestStop) root.data);
		//Checks whether or not he is able to traverse the tree any further.
		boolean stopCheck = hikerCheck(oldHiker);
		
		
		if(stopCheck == false && mountain.mountainDepth(root)<mountain.getHeight(mountain.root)) 
		{
			return;
		}
		
		if(root.left!=null) 
		{
					
						
			Hiker leftHiker= new Hiker(oldHiker);	
			ArrayList<RestStop> leftPaths = (ArrayList<RestStop>) paths.clone();
			pathFinder(mountain,root.left,leftPaths,leftHiker);		
			
			
		}
		
		if(root.right!=null) 
		{
			
						
			Hiker rightHiker = new Hiker(oldHiker);
			ArrayList<RestStop> rightPaths = (ArrayList<RestStop>) paths.clone();
			pathFinder(mountain,root.right,rightPaths,rightHiker);			
			//paths.remove((RestStop) root.data);						
		}		
		
		
	}
		
	
	//Updates the Hiker object at RestStop.
	//@param, Hiker that traverses, and RestStop to be traversed
	//@return Hiker updated to reflect which obstacles he goes through and supplies accumulated.
	static Hiker hikerUpdate(Hiker hiker, RestStop restStop) 
	{
		int originalFood = hiker.getFoodNum();
		int originalAxe = hiker.getAxeNum();
		int originalRaft = hiker.getRaftNum();
		
		hiker.setFoodNum(originalFood+restStop.getFoodCount()-1);
		hiker.setAxeNum(originalAxe+restStop.getAxeCount()-restStop.getTreeCount());
		hiker.setRaftNum(originalRaft+restStop.getRaftCount()-restStop.getRiverCount());

		return hiker;
		
		
	
	}
	
	//Checks if Hiker can traverse further
	//@param Hiker object
	//@return true if enough supplies, false if not enough food or axes/rafts for obstacles.
	public static boolean hikerCheck(Hiker oldHiker) 
	{
		if(oldHiker.getFoodNum()<0) 
		{
			return false;
		}
		if(oldHiker.getAxeNum()<0) 
		{
			return false;
		}
		if(oldHiker.getRaftNum()<0) 
		{
			return false;
		}	
		return true;
	}
		
	
	/*
	
	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	private boolean stopCheck(BSTMountain mountain, BSTNode root) 
	{
		if(root.left==null && root.right==null && mountain.mountainDepth(root)!=mountain.getHeight(mountain.root))
			return false;
		return true;
	}
	*/
	
	//Sets up RestStop objects based on Text File Line.
	//@param String made of fileline, RestStop to be assigned.
	//@return RestStop with set items and obstacles
	static RestStop set(String line,RestStop point) 
	{
		String[] lineSplit = line.split(" ");
		int foodCount = 0;
		int axeCount = 0;
		int treeCount = 0;
		int raftCount = 0;
		int riverCount = 0;
		//System.out.println(lineSplit[0]);
		point.setLabel(lineSplit[0]);
		for(int i = 1; i<lineSplit.length;i++) 
		{
			if(lineSplit[i].equalsIgnoreCase("food"))
			{
				foodCount+=1;
			}
			if(lineSplit[i].equalsIgnoreCase("axe")) 
			{
				axeCount+=1;
			}
			if(lineSplit[i].equalsIgnoreCase("raft")) 
			{
				raftCount+=1;
			}
			if(lineSplit[i].equalsIgnoreCase("river")) 
			{
				riverCount+=1;
			}
			if(lineSplit[i].equalsIgnoreCase("fallen")) 
			{
				try 
				{
					if(lineSplit[i+1].equalsIgnoreCase("tree")) 
					{
						treeCount+=1;
					}
				}
				catch(IndexOutOfBoundsException e) 
				{
					continue;
				}
			}
			{
				
			}
		}
		
		point.setAxeCount(axeCount);
		point.setFoodCount(foodCount);
		point.setRaftCount(raftCount);
		point.setRiverCount(riverCount);
		point.setTreeCount(treeCount);
		
		
		return point;
	}
	
	
	
	//Prints out Path of ArrayList
	//@param ArrayList<RestStop> for entry.
	static void print(ArrayList<RestStop> paths) 
	{
		for(int i = 0;i<paths.size()-1;i++) 
		{
			System.out.printf("%s ", paths.get(i).getLabel());
		}
		
		System.out.printf("%s", paths.get(paths.size()-1).getLabel());
		System.out.println();
	}

	
	
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if (args.length == 0 ) 
		{
			System.err.println("Usage Error: the program expects file name as an argument.\n");
			System.exit(1);
		}
		
		File mountainFile = new File(args[0]); 
		
		if (!mountainFile.exists())
		{
			System.err.println("Error: the file "+mountainFile.getAbsolutePath()+" does not exist.\n");
			System.exit(1);
		}
		
		if (!mountainFile.canRead())
		{
			System.err.println("Error: the file "+mountainFile.getAbsolutePath()+
											" cannot be opened for reading.\n");
			System.exit(1);
		}
		
		
		
		
		Scanner mountainMap = null;
		try {
			mountainMap = new Scanner (mountainFile ) ;
		} catch (FileNotFoundException e) {
			System.err.println("Error: the file "+mountainFile.getAbsolutePath()+
											" cannot be opened for reading.\n");
			System.exit(1);
		}
		
		BSTMountain mountain = new BSTMountain();
		
		String line = null;
		
		//ArrayList<Hiker> hikerList = new ArrayList<Hiker>();
		ArrayList<RestStop> paths = new ArrayList<RestStop>();
		while(mountainMap.hasNextLine()) 
		{
			try 
			{
				RestStop stop = new RestStop();	
				line = mountainMap.nextLine();
				
				set(line,stop);	
				mountain.add(stop);
					
			}
			
			catch(NoSuchElementException ex) 
			{
				System.err.println(line);
				continue;
			}
			
			
			
			
			
		}
		mountainMap.close();
	
		if(mountain.size()==0) 
		{
			System.out.println("File is empty");
			System.exit(1);
		}
		
		BSTNode mountainPeak=mountain.root;
		Hiker Trekker = new Hiker();
		
		pathFinder(mountain,mountainPeak,paths,Trekker);
		
		
		
		for(int i = 0;i<finalPaths2.size()-1;i++) 
		{
			print(finalPaths2.get(i));
			
		}
		print(finalPaths2.get(finalPaths2.size()-1));
		
	
		

	}

}
